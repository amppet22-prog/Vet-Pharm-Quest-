# VPQ Radiology Exam 3 photo pack

87 course radiographs sorted into the game's **existing** Exam 3 photo slots, plus 50 answer-key slide pictures.
Built by Claude on 2026-11-25. Coordination happens on GitHub Issue #40.

## What's in here
| Folder | What it is |
|---|---|
| `e3-…/` (12 folders) | One folder per existing approval-queue slot. Each file is named `slot__NN_what-it-shows.jpg`. |
| `_answer-keys/` | Full slide pictures with the instructor's labels, arrows and text. These are **answer keys only** and must never be used as the question image. |
| `manifest.json` | One record per image: slot, species, region, projection, source file and page, what the slide says, instructor interpretation, rights, privacy note, and review state. |

**Image files contain no answers.** The slide labels ("Normal", arrows) sat on top of the pictures, so the extracted images are clean. There are 3 exceptions where the label is burned into the image: osteopenia 01, stifle 07, and elbow 06. Their manifest record is marked `answer-key-only`.

## Roles in the manifest
- `student`: question image (72)
- `normal-compare`: the slide labels it Normal; use it as the side-by-side comparison (4)
- `answer-key-only`: answer text is burned into the image (3)
- `verify`: you need to confirm which is normal vs abnormal on the slide (8 images: hyperparathyroidism slide p9 and nasal slides p11–12)

## How to upload (uses the game's existing publisher, so no new system)
1. In the game, go to **X-ray room → Radiology Photo Approval Queue → Exam 3**.
2. Click the slot (for example "Practice case 1 · German Shepherd hips"), then click **new**. The publisher opens with the slot ID already filled in.
3. Add the images from that slot's folder. Fill in **Projection** and **Caption** from `manifest.json`. Describe the anatomy, not the diagnosis.
4. Check the rights box only after you have looked at each image at full size and confirmed there are no names or IDs.
5. Publish with your owner password.

**Start small:** the 3 practice-case folders (6 images) are complete patient studies and are the quickest win.

## Rights
Recorded as `owner-attested-lmu-noncommercial`: the owner states that LMU permits course material and assigned textbooks in this non-commercial LMU study game. Every image traces back to its file and page, so any single image can be removed later if needed.

## Review state
`matched-to-case` means Claude confirmed the image matches its slide and slot by looking at it. It is **not** a medical review. Medical review and owner approval stay with the owner.
